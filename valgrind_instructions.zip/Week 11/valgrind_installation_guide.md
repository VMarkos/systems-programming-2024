# Valgrind: Installation Guide

Valgrind Documentation: [https://valgrind.org/docs/](https://valgrind.org/docs/)

## First Way (Automatic)

Just use:

```bash
sudo apt-get install valgrind
```

If this does not work, you might first clean cache and update repos:

```bash
sudo apt-get clean # Does not print anything
sudo apt-get update # Prints some repos names
```

## Second Way (Manual)

There is a high chance the above fails, so...

0. If you do not have `make` installed, first run `sudo apt install make`.
1. Download any resources from [https://valgrind.org/downloads/](https://valgrind.org/downloads/). Make sure you pick the most recent version, at the time of writing this: `valgrind 3.24.0 (tar.bz2) [16MB] - 31 October 2024.`
2. Go to the directory you have downloaded the above, let's say `cd ~/Downloads`.
3. Decompress the tarball using `tar xvf valgrind-3.24.0.tar.bz2` (or the name of your tarball).
4. Change to the unzipped directory `cd valgrind-3.24.0` (or the name of your unzipped directory).
5. Run `./configure`.
6. Run `make`.
7. Then run `sudo make install`.

## How To Use

After installing, close and reopen any active shells to make sure all shell sessions are up to date.

Then, create a simple program, let's say:

```c
// memc.c
#include <stdlib.h>

void f(void) {
   int* x = malloc(10 * sizeof(int));
   x[10] = 0;        // problem 1: heap block overrun
}                    // problem 2: memory leak -- x not freed

int main(void) {
   f();
   return 0;
}
```

As it says, this contains two memory management errors. To run valgrind on this, simply run:

```bash
gcc -o memc memc.c # Assuming you have named your file `memc.c`
valgrind --leak-check=yes ./memc
```

This should print something like the following:

```shell
==17013== Memcheck, a memory error detector
==17013== Copyright (C) 2002-2024, and GNU GPL'd, by Julian Seward et al.
==17013== Using Valgrind-3.24.0 and LibVEX; rerun with -h for copyright info
==17013== Command: ./memc
==17013== 
==17013== Invalid write of size 4
==17013==    at 0x10916B: f (in /home/mc/Documents/Courses/SP/Week 11/memc)
==17013==    by 0x109180: main (in /home/mc/Documents/Courses/SP/Week 11/memc)
==17013==  Address 0x4a7d068 is 0 bytes after a block of size 40 alloc'd
==17013==    at 0x484580F: malloc (vg_replace_malloc.c:446)
==17013==    by 0x10915E: f (in /home/mc/Documents/Courses/SP/Week 11/memc)
==17013==    by 0x109180: main (in /home/mc/Documents/Courses/SP/Week 11/memc)
==17013== 
==17013== 
==17013== HEAP SUMMARY:
==17013==     in use at exit: 40 bytes in 1 blocks
==17013==   total heap usage: 1 allocs, 0 frees, 40 bytes allocated
==17013== 
==17013== 40 bytes in 1 blocks are definitely lost in loss record 1 of 1
==17013==    at 0x484580F: malloc (vg_replace_malloc.c:446)
==17013==    by 0x10915E: f (in /home/mc/Documents/Courses/SP/Week 11/memc)
==17013==    by 0x109180: main (in /home/mc/Documents/Courses/SP/Week 11/memc)
==17013== 
==17013== LEAK SUMMARY:
==17013==    definitely lost: 40 bytes in 1 blocks
==17013==    indirectly lost: 0 bytes in 0 blocks
==17013==      possibly lost: 0 bytes in 0 blocks
==17013==    still reachable: 0 bytes in 0 blocks
==17013==         suppressed: 0 bytes in 0 blocks
==17013== 
==17013== For lists of detected and suppressed errors, rerun with: -s
==17013== ERROR SUMMARY: 2 errors from 2 contexts (suppressed: 0 from 0)
```

As you can see, this keeps track of (almost) all memory leaks and almost all ways to access that memory again (if possible).